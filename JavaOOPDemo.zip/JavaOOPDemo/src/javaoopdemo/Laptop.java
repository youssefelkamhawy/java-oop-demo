/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaoopdemo;

/**
 *Subclass representing a laptop with its own troubleshooting process.
 * @author Youssef Elkamhawy
 */
public class Laptop extends Device {

    public Laptop(String brand, String model) {
        super(brand, model);
    }

    @Override
    public void troubleshoot() {
        System.out.println("Running diagnostics on laptop: " + getBrand() + " " + getModel());
        System.out.println("Checking operating system, RAM, and drivers...");
    }
}
