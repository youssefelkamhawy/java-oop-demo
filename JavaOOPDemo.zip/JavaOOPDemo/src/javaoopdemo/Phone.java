/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaoopdemo;

/**
 *Subclass representing a smartphone with specific diagnostic behavior.
 * @author Youssef Elkamhawy
 */
public class Phone extends Device {

    public Phone(String brand, String model) {
        super(brand, model);
    }

    @Override
    public void troubleshoot() {
        System.out.println("Analyzing phone performance: " + getBrand() + " " + getModel());
        System.out.println("Checking battery health and network connection...");
    }
}
