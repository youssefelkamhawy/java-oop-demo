/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package javaoopdemo;

/**
 *Main program that creates devices, assigns support tickets, and runs diagnostics.
 * @author Youssef Elkamhawy
 */
public class TechSupportApp {
    public static void main(String[] args) {
        Device laptop = new Laptop("Dell", "XPS 15");
        Device phone = new Phone("Samsung", "Galaxy S22");

        SupportTicket ticket1 = new SupportTicket(1, laptop, "Slow performance and overheating");
        SupportTicket ticket2 = new SupportTicket(2, phone, "Wi-Fi not connecting");

        ticket1.displayTicketInfo();
        ticket1.troubleshootDevice();
        ticket1.resolveTicket();

        System.out.println();

        ticket2.displayTicketInfo();
        ticket2.troubleshootDevice();
    }
}
