/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaoopdemo;

/**
 *Manages device issues, storing details and tracking resolution status.
 * @author Youssef Elkamhawy
 */
public class SupportTicket {
    private int ticketId;
    private Device device;
    private String issueDescription;
    private boolean resolved;

    public SupportTicket(int ticketId, Device device, String issueDescription) {
        this.ticketId = ticketId;
        this.device = device;
        this.issueDescription = issueDescription;
        this.resolved = false;
    }

    public void resolveTicket() {
        resolved = true;
        System.out.println("✅ Ticket #" + ticketId + " has been resolved!");
    }

    public void displayTicketInfo() {
        System.out.println("---- Ticket #" + ticketId + " ----");
        System.out.println("Device: " + device);
        System.out.println("Issue: " + issueDescription);
        System.out.println("Status: " + (resolved ? "Resolved" : "Pending"));
        System.out.println("----------------------------");
    }

    public void troubleshootDevice() {
        device.troubleshoot();
    }
}
