/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaoopdemo;

/**
 *Abstract base class that defines common attributes and behavior for all devices.
 * @author Youssef Elkamhawy
 */
public abstract class Device {
    private String brand;
    private String model;

    public Device(String brand, String model) {
        this.brand = brand;
        this.model = model;
    }

    public String getBrand() {
        return brand;
    }

    public String getModel() {
        return model;
    }

    public abstract void troubleshoot();

    @Override
    public String toString() {
        return brand + " " + model;
    }
}
